package com.generic;

import java.util.Hashtable;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WrapperFunctions extends Base {
	
	private WebDriver driver;
	private WebDriverWait wait;
	private Pojo objPojo;
	
	public WrapperFunctions(Pojo pojo) {
		this.objPojo = pojo;
	}
	
	
	public void waitForElementPresence(By locator) throws Exception {
		objPojo.getWebDriverWait().until(ExpectedConditions.presenceOfElementLocated(locator));
	}
	
	
	public void click(By locator) {
		try {
			waitForElementPresence(locator);
			WebElement we = objPojo.getDriver().findElement(locator);
			we.click();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	public void setText(By locator, String fieldValue) {
		try {
			WebElement webElement = objPojo.getDriver().findElement(locator);
			clearText(webElement);
			webElement.sendKeys(fieldValue);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void clearText(WebElement webElement) {
		try {
			webElement.sendKeys(Keys.chord(Keys.CONTROL, "a"), Keys.DELETE);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public String dpString(String columnHeader) {
		Hashtable<String, String> dataPoolHashTable = Base.testDataForTest;
		try {
			if (dataPoolHashTable.get(columnHeader) == null)
				return "";
			else {
				//Log.info("I found, Key: " + columnHeader + " Value : " + dataPoolHashTable.get(columnHeader));
				return dataPoolHashTable.get(columnHeader);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "";
		}
	}
	
	
	
	

}
