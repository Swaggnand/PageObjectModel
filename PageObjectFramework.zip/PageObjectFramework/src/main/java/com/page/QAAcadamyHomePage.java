package com.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.generic.Pojo;
import com.generic.WrapperFunctions;

public class QAAcadamyHomePage {
	
	public WebDriver driver;
	public WrapperFunctions objWrapperFunctions;
	private Pojo objPojo;
	
	public QAAcadamyHomePage(Pojo objPojo) {
		this.objPojo=objPojo;
	}


	
	By lnkLogin = By.xpath("//a[contains(@href,'sign_in')]");
	
	
	public void clickOnLoginLink() {
		objPojo.getObjWrapperFunctions().click(lnkLogin);
	}
	
}
